#include <iostream>
#include <vector>
#include <climits>

using namespace std;

// Define a class to represent a weighted graph
class Graph {
public:
    int V; // Number of vertices
    vector<vector<pair<int, int>>> adj; // Adjacency list (vertex, weight)

    // Constructor to initialize the graph with a given number of vertices
    Graph(int vertices) {
        V = vertices;
        adj.resize(V); // Resize the adjacency list to fit the number of vertices
    }

    // Function to add an edge to the graph
    void addEdge(int v, int w, int weight) {
        adj[v].push_back(make_pair(w, weight)); // Add an edge from v to w
        adj[w].push_back(make_pair(v, weight)); // Add an edge from w to v (undirected graph)
    }
};

// Prim's Algorithm to find the Minimum Spanning Tree (MST)
vector<int> prim(Graph& graph, int startVertex) {
    vector<int> parent(graph.V, -1); // Parent array to store the MST
    vector<int> key(graph.V, INT_MAX); // Key array to store minimum edge weight for each vertex
    vector<bool> inMST(graph.V, false); // Array to check if a vertex is included in MST

    // Start with the given vertex, its key is 0
    key[startVertex] = 0;

    // Loop to find the MST
    for (int count = 0; count < graph.V - 1; count++) {
        // Find the vertex with the minimum key that is not yet included in MST
        int minKey = INT_MAX;
        int u = -1;
        for (int v = 0; v < graph.V; v++) {
            if (!inMST[v] && key[v] < minKey) {
                minKey = key[v];
                u = v;
            }
        }

        // Include the chosen vertex in the MST
        inMST[u] = true;

        // Update the key and parent for adjacent vertices
        for (const auto& neighbor : graph.adj[u]) {
            int v = neighbor.first;
            int weight = neighbor.second;

            // If the vertex v is not in MST and the weight of the edge is smaller than the current key, update it
            if (!inMST[v] && weight < key[v]) {
                key[v] = weight;
                parent[v] = u;
            }
        }
    }

    return parent; // Return the parent array representing the MST
}

int main() {
    // Create a graph with 5 vertices
    Graph graph(5);

    // Add edges with their respective weights
    graph.addEdge(0, 1, 2);
    graph.addEdge(0, 3, 6);
    graph.addEdge(1, 2, 3);
    graph.addEdge(1, 3, 8);
    graph.addEdge(1, 4, 5);
    graph.addEdge(2, 4, 7);
    graph.addEdge(3, 4, 9);

    int startVertex = 0;

    // Find the Minimum Spanning Tree using Prim's algorithm
    vector<int> parent = prim(graph, startVertex);

    // Output the edges in the Minimum Spanning Tree
    cout << "Edges in the Minimum Spanning Tree:" << endl;
    for (int i = 1; i < graph.V; i++) {
        cout << "Edge: " << parent[i] << " - " << i << " (Weight: " 
             << graph.adj[i][parent[i]].second << ")" << endl;
    }

    return 0;
}
