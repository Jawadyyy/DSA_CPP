#include <iostream>
#include <vector>
#include <queue>
#include <set>
#include <limits>
using namespace std;

class Graph {
public:
    Graph(int V, bool isDirected); // Constructor to initialize the graph
    void addEdge(int v, int w, int weight); // Add an edge with weight between vertices
    void printGraph(); // Print the adjacency list
    void BFS(int start); // Perform BFS
    void DFS(int start); // Perform DFS (using recursion)
    vector<int> dijkstra(int startVertex); // Perform Dijkstra's Algorithm

private:
    int V; // Number of vertices
    bool isDirected; // True if the graph is directed
    vector<vector<pair<int, int>>> adj; // Adjacency list with (vertex, weight) pairs
};

Graph::Graph(int V, bool isDirected) {
    this->V = V;
    this->isDirected = isDirected;
    adj.resize(V);
}

void Graph::addEdge(int v, int w, int weight) {
    adj[v].push_back(make_pair(w, weight)); // Add edge from v to w with a weight
    if (!isDirected) {
        adj[w].push_back(make_pair(v, weight)); // For undirected graph, add edge from w to v
    }
}

void Graph::printGraph() {
    for (int v = 0; v < V; ++v) {
        cout << "Vertex " << v << " is connected to:";
        for (const auto& edge : adj[v]) {
            cout << " " << edge.first << " (Weight: " << edge.second << ")";
        }
        cout << endl;
    }
}

// BFS function (simple)
void Graph::BFS(int start) {
    vector<bool> visited(V, false); // Create a visited array
    queue<int> q; // Create a queue for BFS

    visited[start] = true;
    q.push(start); // Start from the 'start' node

    while (!q.empty()) {
        int v = q.front(); // Get the front element
        q.pop();           // Remove it from the queue
        cout << v << " ";  // Print the current vertex

        // Check all adjacent vertices of the current vertex
        for (int i = 0; i < adj[v].size(); ++i) {
            int neighbor = adj[v][i].first;
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                q.push(neighbor); // Push the unvisited neighbor to the queue
            }
        }
    }
    cout << endl;
}

// DFS function (simple and recursive)
void Graph::DFS(int start) {
    static vector<bool> visited(V, false); // Create a visited array (static to persist across recursive calls)
    
    // Mark the current node as visited and print it
    visited[start] = true;
    cout << start << " ";

    // Visit all unvisited neighbors
    for (int i = 0; i < adj[start].size(); ++i) {
        int neighbor = adj[start][i].first;
        if (!visited[neighbor]) {
            DFS(neighbor); // Recursively visit the neighbor
        }
    }
}

vector<int> Graph::dijkstra(int startVertex) {
    vector<int> distance(V, numeric_limits<int>::max()); // Initialize distances to infinity
    set<pair<int, int>> minDistances; // Set to store (distance, vertex) pairs

    distance[startVertex] = 0; // Set the distance of the start vertex to 0
    minDistances.insert(make_pair(0, startVertex));

    while (!minDistances.empty()) {
        // Get the vertex with the minimum distance from the set
        pair<int, int> current = *minDistances.begin();
        minDistances.erase(minDistances.begin());

        int u = current.second;

        // Explore all adjacent vertices
       for (auto& neighbor : adj[u]) {
        int v = neighbor.first;
        int weight = neighbor.second;

        // Check if we found a shorter path to vertex 'v'
            if (distance[u] + weight < distance[v]) {
            distance[v] = distance[u] + weight;
            minDistances.insert({distance[v], v});
            }
        }

    }

    return distance;
}

vector<int> Graph::dijkstra(int startv) {
    vector<int> distance(V,numeric_limits<int>::max());
    set<pair<int,int>> minDistances;

    distance[startv] =0;
    minDistances.insert(make_pair(0,startv));

    while(!minDistances.empty()) {
        pair<int,int> current = *minDistances.begin();
        minDistances.erase(minDistances.begin());

        int u = current.second;

        for(auto& neighbour : adj[u]) {
            int v = neighbour.first;
            int weight = neighbour.second;
            if(distance[u] + weight < distance[v]) {
                distance[v] = distance[u] + weight;
                minDistances.insert({distance[v],v});
            }
        }
    }

    return distance;
}

int main() {
    int V = 5; // Number of vertices
    bool isDirected;

    cout << "Enter 0 for undirected graph or 1 for directed graph: ";
    cin >> isDirected;

    Graph graph(V, isDirected);

    // Add edges to the graph (with weights)
    graph.addEdge(0, 1, 10);
    graph.addEdge(0, 2, 5);
    graph.addEdge(1, 2, 2);
    graph.addEdge(1, 3, 1);
    graph.addEdge(2, 3, 9);
    graph.addEdge(3, 4, 4);

    if (isDirected) {
        graph.addEdge(4, 0, 7); // Additional edge for directed graph
    }

    // Print the adjacency list of the graph
    graph.printGraph();

    // Perform BFS starting from vertex 0
    cout << "BFS starting from vertex 0: ";
    graph.BFS(0);

    // Perform DFS starting from vertex 0
    cout << "DFS starting from vertex 0: ";
    graph.DFS(0);
    cout << endl;

    // Perform Dijkstra's algorithm starting from vertex 0
    vector<int> distances = graph.dijkstra(0);
    cout << "Shortest distances from vertex 0: ";
    for (int i = 0; i < distances.size(); ++i) {
        cout << "Vertex " << i << ": " << distances[i] << " ";
    }
    cout << endl;

    return 0;
}
