#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// Structure to represent an edge in the graph
struct Edge {
    int source, destination, weight; // The source and destination vertices, and the weight of the edge

    // Comparator function for sorting edges by weight
    bool operator<(const Edge& other) const {
        return weight < other.weight; // Compare the weight of two edges
    }
};

// Define a class to represent a weighted graph
class Graph {
public:
    int V; // Number of vertices
    vector<Edge> edges; // List of edges

    // Constructor to initialize the number of vertices
    Graph(int vertices) {
        V = vertices;
    }

    // Function to add an edge to the graph
    void addEdge(int source, int destination, int weight) {
        edges.push_back({source, destination, weight}); // Add edge to the list
    }
};

// Function to find the parent of a vertex (used for cycle detection)
int findParent(vector<int>& parent, int node) {
    if (parent[node] == node) // If the node is its own parent, return it
        return node;

    return findParent(parent, parent[node]); // Otherwise, find the parent of the parent (recursively)
}

// Kruskal's algorithm to find the minimum spanning tree (MST)
vector<Edge> kruskal(Graph& graph) {
    vector<Edge> result; // This will store the edges of the Minimum Spanning Tree (MST)
    int vertices = graph.V; // Get the number of vertices in the graph

    // Sort the edges in non-decreasing order of their weights
    sort(graph.edges.begin(), graph.edges.end());

    vector<int> parent(vertices); // To store the parent of each vertex

    // Initialize each node as its own parent
    for (int i = 0; i < vertices; i++) {
        parent[i] = i; // Every vertex is initially its own parent
    }

    int edgeCount = 0; // Counter for the edges in the MST
    int i = 0; // Index to loop through the edges

    // Process edges until we have V-1 edges in the MST or no more edges left
    while (edgeCount < vertices - 1 && i < graph.edges.size()) {
        const Edge& currentEdge = graph.edges[i]; // Get the current edge

        // Find the parent of the source and destination vertices
        int sourceParent = findParent(parent, currentEdge.source);
        int destinationParent = findParent(parent, currentEdge.destination);

        // If the source and destination do not have the same parent, add the edge to the MST
        if (sourceParent != destinationParent) {
            result.push_back(currentEdge); // Add edge to the MST
            parent[sourceParent] = destinationParent; // Union the sets by making the source parent the destination parent
            edgeCount++; // Increment the edge count in MST
        }

        i++; // Move to the next edge
    }

    return result; // Return the edges of the MST
}

int main() {
    // Create a graph with 6 vertices
    Graph graph(6);

    // Add edges with their weights
    graph.addEdge(0, 1, 4);
    graph.addEdge(0, 2, 4);
    graph.addEdge(1, 2, 2);
    graph.addEdge(1, 3, 3);
    graph.addEdge(1, 4, 7);
    graph.addEdge(2, 3, 5);
    graph.addEdge(2, 4, 6);
    graph.addEdge(3, 4, 8);
    graph.addEdge(3, 5, 6);
    graph.addEdge(4, 5, 9);

    // Find the Minimum Spanning Tree using Kruskal's algorithm
    vector<Edge> mst = kruskal(graph);

    // Print the edges of the Minimum Spanning Tree
    cout << "Edges in the Minimum Spanning Tree:" << endl;
    for (const Edge& edge : mst) {
        cout << edge.source << " - " << edge.destination << " (Weight: " << edge.weight << ")" << endl;
    }

    return 0;
}
