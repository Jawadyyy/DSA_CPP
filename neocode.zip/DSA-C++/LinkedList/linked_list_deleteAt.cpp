#include <iostream>

using namespace std;

class Node {
public:
    int value;
    Node* next;

    Node(int value) {
        this->value = value;
        next = NULL;
    }
};

void deleteFirst(Node **h) {
    if (*h == NULL) {
        cout << "List is Empty" << endl;
        return;
    }
    Node *ptr = *h;
    *h = (*h)->next;
    delete ptr;
}

void deleteAtK(Node **h, int k) {
    if (*h == NULL) {
        cout << "List is Empty" << endl;
        return;
    }
    
    if (k == 0) {
        deleteFirst(h);
        return;
    }

    Node *current = *h;
    for (int i = 0; i < k - 1 && current->next != NULL; ++i) {
        current = current->next;
    }

    if (current->next == NULL) {
        cout << "Position out of bounds" << endl;
        return;
    }

    Node *nodeToDelete = current->next;
    current->next = nodeToDelete->next;
    delete nodeToDelete;
}

void printList(Node *n) {
    while (n != NULL) {
        cout << n->value << " ";
        n = n->next;
    }
    cout << endl;
}

int main() {
    Node *head = new Node(5);
    Node *second = new Node(12);
    Node *third = new Node(9);
    Node *fourth = new Node(20);

    head->next = second;
    second->next = third;
    third->next = fourth;
    fourth->next = NULL;

    cout << "The List: ";
    printList(head);

    int k = 2;
    cout << "Deleting node at position " << k << endl;
    deleteAtK(&head, k);

    cout << "The List After Deleting Node at Position " << k << ": ";
    printList(head);

    return 0;
}
