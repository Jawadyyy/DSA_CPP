#include <iostream>
using namespace std;

// Definition of a TreeNode
class TreeNode {
public:
    int value;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) : value(val), left(nullptr), right(nullptr) {}
};

// Definition of the BinarySearchTree class
class BinarySearchTree {
private:
    TreeNode* root;

    // Helper function to insert a node recursively
    TreeNode* insertNode(TreeNode* node, int value) {
        if (node == nullptr) {
            return new TreeNode(value);
        }
        if (value < node->value) {
            node->left = insertNode(node->left, value);
        } else if (value > node->value) {
            node->right = insertNode(node->right, value);
        }
        return node;
    }

    // Helper function for in-order traversal
    void inorderTraversal(TreeNode* node) {
        if (node == nullptr) {
            return;
        }
        inorderTraversal(node->left);
        cout << node->value << " ";
        inorderTraversal(node->right);
    }

    // Helper function to search for a value recursively
    bool searchNode(TreeNode* node, int value) {
        if (node == nullptr) {
            return false;
        }
        if (value == node->value) {
            return true;
        } else if (value < node->value) {
            return searchNode(node->left, value);
        } else {
            return searchNode(node->right, value);
        }
    }

public:
    // Constructor to initialize an empty tree
    BinarySearchTree() : root(nullptr) {}

    // Insert a value into the BST
    void insert(int value) {
        root = insertNode(root, value);
    }

    // Perform in-order traversal and print values
    void inorder() {
        inorderTraversal(root);
        cout << endl;
    }

    // Search for a value in the BST
    bool search(int value) {
        return searchNode(root, value);
    }
};

// Main function to demonstrate the Binary Search Tree
int main() {
    BinarySearchTree bst;

    // Insert elements into the BST
    bst.insert(10);
    bst.insert(5);
    bst.insert(15);
    bst.insert(7);
    bst.insert(12);
    bst.insert(3);

    // In-order traversal (prints values in ascending order)
    cout << "In-order Traversal: ";
    bst.inorder();

    // Search for specific values
    cout << "Searching for 7: " << (bst.search(7) ? "Found" : "Not Found") << endl;
    cout << "Searching for 11: " << (bst.search(11) ? "Found" : "Not Found") << endl;

    return 0;
}
