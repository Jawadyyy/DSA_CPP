#include <iostream>
using namespace std;

class Node {
public:
    int value;
    Node *next;

    Node(int value) {
        this->value = value;
        next = NULL;
    }
};

void reverseList(Node *&h) {
    Node* previous;
    Node* current;
    Node* next;

    previous = NULL;
    current = h;

    while(current != NULL) {
        next = current->next;
        current->next = previous;
        previous = current;
        current = next;
    }

    h = previous;
}

void printList(Node *head) {
    if (head == NULL) {
        cout << "The list is empty." << endl;
        return;
    }

    Node *current = head;
    while (current != NULL) {
        cout << current->value << " -> ";
        current = current->next;
    }
    cout << "NULL" << endl;
}

int main() {
    int n;
    cout << "Enter the number of nodes: ";
    cin >> n;

    Node *head = NULL;
    Node *tail = NULL;

    for (int i = 1; i <= n; i++) {
        int val;
        cout << "Enter value for node " << i << ": ";
        cin >> val;
        
        Node *newNode = new Node(val);

        if (head == NULL) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    cout << "Linked list (Before Reversing): ";
    printList(head);
    reverseList(head);
    cout << "Linked list (After Reversing): ";
    printList(head);

    return 0;
}
