#include <iostream>
#include <vector>

using namespace std;

class Graph
{
public:
    Graph(int V);
    void addEdge(int v, int w);
    void printGraph();

private:
    int V;
    vector<vector<int>> adj;
};

Graph::Graph(int V)
{
    this->V = V;
    adj.resize(V);
}

void Graph::addEdge(int v, int w)
{
    adj[v].push_back(w);
    adj[w].push_back(v);
}

void Graph::printGraph()
{
    for (int v = 0; v < V; ++v)
    {
        cout << "Vertex " << v << " is Connected to:";
        for (const int &neighbour : adj[v])
        {
            cout << " " << neighbour;
        }

        cout << endl;
    }
}

int main()
{

    int V = 5;
    Graph graph(V);

    graph.addEdge(0, 1);
    graph.addEdge(0, 2);
    graph.addEdge(1, 3);
    graph.addEdge(2, 4);

    graph.printGraph();
    return 0;
}