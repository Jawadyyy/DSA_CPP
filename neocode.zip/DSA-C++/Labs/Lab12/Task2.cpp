#include <iostream>
using namespace std;

class MinHeap {
private:
    int heap[100];  
    int size;     

    void heapify(int i) {
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        int smallest = i;

        if (left < size && heap[left] < heap[smallest]) {
            smallest = left;
        }
        if (right < size && heap[right] < heap[smallest]) {
            smallest = right;
        }
        if (smallest != i) {
            swap(heap[i], heap[smallest]);
            heapify(smallest);
        }
    }

public:
    MinHeap() {
        size = 0;
    }

    void insert(int value) {
        if (size == 100) {
            cout << "Heap is full!" << endl;
            return;
        }
        heap[size] = value;
        int i = size;
        size++;

        while (i > 0 && heap[i] < heap[(i - 1) / 2]) {
            swap(heap[i], heap[(i - 1) / 2]);
            i = (i - 1) / 2;
        }
    }

    void pop() {
        if (size == 0) return;
        heap[0] = heap[size - 1];
        size--;
        heapify(0);
    }

    int top() {
        return size > 0 ? heap[0] : -1;
    }

    int getSize() {
        return size;
    }
};

int findKthLargest(int nums[], int n, int k) {
    MinHeap minHeap;

    for (int i = 0; i < n; ++i) {
        minHeap.insert(nums[i]);
        if (minHeap.getSize() > k) {
            minHeap.pop();
        }
    }

    return minHeap.top();
}

int main() {
    int nums[] = {10, 5, 20, 15, 30, 25};
    int n = sizeof(nums) / sizeof(nums[0]);
    int k = 3;

    cout << "The " << k << "th largest element is: " << findKthLargest(nums, n, k) << endl;

    return 0;
}
