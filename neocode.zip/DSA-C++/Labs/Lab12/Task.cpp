#include <iostream>
using namespace std;

class minHeap {
private:
    int heap[100]; 
    int size;   

    void heapify(int i) {
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        int smallest = i;

        if (left < size && heap[left] < heap[smallest]) {
            smallest = left;
        }
        if (right < size && heap[right] < heap[smallest]) {
            smallest = right;
        }
        if (smallest != i) {
            swap(heap[i], heap[smallest]);
            heapify(smallest);
        }
    }

public:
    minHeap() {
        size = 0;
    }

    void insert(int value) {
        if (size == 100) {
            cout << "Heap is full!" << endl;
            return;
        }
        heap[size] = value;
        int i = size;
        size++;

        while (i > 0 && heap[i] < heap[(i - 1) / 2]) {
            swap(heap[i], heap[(i - 1) / 2]);
            i = (i - 1) / 2;
        }
    }

    void deleteValue(int value) {
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (heap[i] == value) {
                index = i;
                break;
            }
        }

        if (index == -1) return;

        heap[index] = heap[size - 1];
        size--;
        heapify(index);
    }

    int getMin() {
        if (size > 0) return heap[0];
        return -1;
    }
};

int main() {
    cout << "Enter the number of queries: ";
    int Q;
    cin >> Q;

    minHeap heap;

    cout << "Menu:" << endl;
    cout << "1 - Insert x into the heap:" << endl;
    cout << "2 - Delete x from the heap:" << endl;
    cout << "3 - Print the minimum element in the heap:" << endl;

    while (Q--) {
        int type;
        cin >> type;

        if (type == 1) {
            int x;
            cout << "Enter the value to insert: ";
            cin >> x;
            heap.insert(x);
        } else if (type == 2) {
            int x;
            cout << "Enter the value to delete: ";
            cin >> x;
            heap.deleteValue(x);
        } else if (type == 3) {
            cout << "Minimum element: " << heap.getMin() << endl;
        } else {
            cout << "Invalid query type. Please enter 1, 2, or 3:" << endl;
        }
    }

    return 0;
}
