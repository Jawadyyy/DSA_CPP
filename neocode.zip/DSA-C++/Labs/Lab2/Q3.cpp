#include <iostream>
using namespace std;

int main() {
    int a = 0, b = 0;
    int N = 4, M = 4;

    for (int i = 0; i < M; i++) {
        b = b + 40;
    }

    for (int i = 0; i < M; i++) {
        b = b + 40;
        for (int i = 0; i < M; i++) {
            b = b + 40;
            for (int i = 0; i < M; i++) {
                b = b + 40;
            }
        }
    }

    cout << a << " " << b;
    return 0;
}