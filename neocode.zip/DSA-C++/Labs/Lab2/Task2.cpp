#include <iostream>
using namespace std;

int main() {

    string str;
    char ray[100];
    char ary[100];
    char* ptr;

    cout << "Enter a String: " << endl;
    getline(cin, str);

    for(int i = 0; i < str.length(); i++) {
        ray[i] = str[i];
    }
    ray[str.length()] = '\0';

    ptr = ray;

    cout << "Displaying using pointer: " << endl;
    for(int i = 0; i < str.length(); i++) {
        cout << *(ptr + i);
    }
    cout << endl;

    for(int i = 0, j = str.length() - 1; i < str.length(); i++, j--) {
        ary[i] = *(ptr + j);
    }
    ary[str.length()] = '\0';

    cout << "Reversing: " << endl;
    ptr = ary;
    for(int i = 0; i < str.length(); i++) {
        cout << *(ptr + i);
    }
    cout << endl;

    return 0;
}
