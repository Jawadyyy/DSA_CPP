#include <iostream>
using namespace std;

int main() {
    int a = 0, b = 0; 
    int N = 4, M = 4;

    for (int i = 1; i <= N; i++) {
        a += i;
    }
    // Time complexity: O(N)

    for (int i = 1; i <= M; i++) {
        b += 2 * i;
    }
    // Time complexity: O(M)

    cout << "Sum of first N positive integers: " << a << endl;
    cout << "Sum of first M even integers: " << b << endl;

    return 0;
}
