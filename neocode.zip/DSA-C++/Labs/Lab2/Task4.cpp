#include <iostream>
using namespace std;

int factorial_recursive(int n) {
    if(n == 0 || n == 1) {
        return 1;
    }
    else {
        return n * factorial_recursive(n - 1);
    }
    // Time Complexity: O(n) - The function calls itself n times
    // Space Complexity: O(n) - Due to the recursive call stack
}

int factorial_iterative(int n) {
    int result = 1;
    for (int j = 1; j <= n; j++) {
        result *= j;
    }
    return result;
    // Time Complexity: O(n) - The loop runs n times
    // Space Complexity: O(1) - Only a few variables are used, no extra memory
}

int main()
{
    int n;

    cout << "Enter a positive integer: ";
    cin >> n;

    if (n < 0) {
        cout << "Enter a positive number." << endl;
    } else {
        cout << "Factorial (Recursive): " << factorial_recursive(n) << endl;

        cout << "Factorial (Iterative): " << factorial_iterative(n) << endl;
    }

    return 0;
}
