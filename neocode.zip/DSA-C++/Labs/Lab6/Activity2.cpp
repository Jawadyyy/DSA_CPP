#include <iostream>
using namespace std;

const int max_size = 100;

class Queue
{
private:
    int ray[max_size];
    int front;
    int back;

public:
    Queue()
    {
        front = -1;
        back = -1;
    }

    void enqueue(int x)
    {
        if (isFull()) {
            cout << "Queue overflow" << endl;
            return;
        }

        if(isEmpty()) {
            front++;
        }

        back = (back + 1) % max_size;
        ray[back] = x;
    }

    int dequeue()
    {
        if(isEmpty()) {
            cout << "Queue underflow" << endl;
            return -1;
        }

        int dqItem = ray[front];
        if(front == back) {
            front = -1;
            back = -1;
        }
        else {
            front = (front+1) % max_size;
        }
        cout << "Dequeued: " << dqItem << endl;
        return dqItem;
    }

    bool isFull() {
        return (front == (back + 1) % max_size);
    }

    bool isEmpty() {
        return (front == -1 && back == -1);   
    }

    void display()
    {
        if (front == -1 || front > back)
        {
            cout << "Queue is empty" << endl;
            return;
        }

        cout << "Queue elements: ";
        for (int i = front; i <= back; i++)
        {
            cout << ray[i] << " ";
        }
        cout << endl;
    }
};

int main()
{
    Queue q;

    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.display();

    q.dequeue();
    q.dequeue();
    q.dequeue();

    return 0;
}
