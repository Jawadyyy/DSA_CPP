#include <iostream>
using namespace std;

const int max_size = 100;

class Queue
{
private:
    int ray[max_size];
    int front;
    int back;

public:
    Queue()
    {
        front = -1;
        back = -1;
    }

    void enqueue(int x)
    {
        if (back == max_size)
        {
            cout << "Queue overflow" << endl;
            return;
        }

        if (front == -1)
        {
            front++;
        }

        back++;
        ray[back] = x;
    }

    void dequeue()
    {
        if (front == -1 || front > back)
        {
            cout << "Queue underflow" << endl;
            return;
        }

        cout << "Dequeued: " << ray[front] << endl;
        front++;
    }

    void display()
    {
        if (front == -1 || front > back)
        {
            cout << "Queue is empty" << endl;
            return;
        }

        cout << "Queue elements: ";
        for (int i = front; i <= back; i++)
        {
            cout << ray[i] << " ";
        }
        cout << endl;
    }
};

int main()
{
    Queue q;

    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.display();

    q.dequeue();
    q.dequeue();
    q.dequeue();

    return 0;
}
