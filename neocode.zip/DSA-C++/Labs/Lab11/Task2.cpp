#include <iostream>
using namespace std;

class DisjointSet {
public:
    DisjointSet(int n) {
        parent = new int[n];
        for (int i = 0; i < n; ++i) {
            parent[i] = i;
        }
    }

    ~DisjointSet() {
        delete[] parent;
    }

    int find(int x) {
        if (parent[x] != x) {
            parent[x] = find(parent[x]);
        }
        return parent[x];
    }

    bool unionSets(int x, int y) {
        int rootX = find(x);
        int rootY = find(y);
        if (rootX == rootY) {
            return true;
        }
        parent[rootX] = rootY;
        return false;
    }

private:
    int* parent;
};

bool hasCycle(int n, int edges[][2], int numEdges) {
    DisjointSet ds(n);
    for (int i = 0; i < numEdges; ++i) {
        int u = edges[i][0];
        int v = edges[i][1];
        if (ds.unionSets(u, v)) {
            return true;
        }
    }
    return false;
}

int main() {
    int n = 4;
    int edges[][2] = {{0, 1}, {1, 2}, {2, 0}, {2, 3}};
    int numEdges = 4;

    if (hasCycle(n, edges, numEdges)) {
        cout << "Cycle detected in the graph!" << endl;
    } else {
        cout << "No cycle detected in the graph!" << endl;
    }

    return 0;
}
