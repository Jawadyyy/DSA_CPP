#include <iostream>

using namespace std;

void display(int array [][4]) {
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            cout << array[i][j] << " " ;
        }
        cout << endl;
    }
}

void rowsum(int array[][4])
{
    int sum;

    for (int i = 0; i < 4; i++)
    {
        sum = 0;
        for (int j = 0; j < 4; j++)
        {
            sum = sum + array[i][j];
        }

        cout << "The sum of row " << i+1 << " is: " << sum << endl;
    }
}

void colsum(int array[][4])
{
    int sum;

    for (int i = 0; i < 4; i++)
    {
        sum = 0;

        for (int j = 0; j < 4; j++)
        {
            sum = sum + array[j][i];
        }
        cout << "The sum of row " << i+1 << " is: " << sum << endl;
    }
}

void transpose(int array[][4]) {
    int transpose [4][4];

    for (int i = 0; i < 4; ++i)
    {
        for (int j = 0; j < 4; ++j)
        {
            transpose[j][i]= array[i][j];
        }
    }

    display(transpose);
}

int main()
{

    int arr[4][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};

    cout << "Original Array: " << endl;

    display(arr);

    cout << "Transposed Array: " << endl;
    transpose(arr);

    rowsum(arr);
    colsum(arr);

    return 0;
}