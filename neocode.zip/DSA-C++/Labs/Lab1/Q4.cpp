#include <iostream>

using namespace std;

class Task
{
public:
    int fib(int n)
    {
        if (n < 0)
        {
            return -1;
        }

        return fibRecursive(n);
    }

private:
    int fibRecursive(int n)
    {
        if (n <= 1)
        {
            return n;
        }

        return fibRecursive(n - 1) + fibRecursive(n - 2);
    }
};

int main()
{
    Task obj;
    int num;

    cout << "Enter number: " << endl;
    cin >> num;

    cout << "Output: " << obj.fib(num);

    return 0;
}
