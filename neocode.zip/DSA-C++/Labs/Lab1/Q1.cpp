#include <iostream>
using namespace std;

class Array
{
public:
    void displayRange(int (&ray)[5])
    {
        for (const int &n : ray)
        {
            cout << n << " ";
        }
    }

    void displayTraditional(int ray[5])
    {

        for (int i = 0; i < 5; ++i)
        {
            cout << ray[i] << " ";
        }
    }
};

int main()
{
    Array obj;

    int numbers[5] = {7, 5, 6, 12, 35};

    cout << "Using Range Based For Loop The numbers are: " << endl;
    obj.displayRange(numbers);

    cout << endl;

    cout << "Using Traditional For Loop The numbers are: " << endl;
    obj.displayTraditional(numbers);

    return 0;
}