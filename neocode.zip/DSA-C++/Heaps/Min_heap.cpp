#include <iostream>
#include <vector>

class MinHeap {
    std::vector<int> heap;

public:
    void insert(int value) {
        heap.push_back(value);
        int i = heap.size() - 1;

        // Bubble up to maintain heap property
        while (i > 0 && heap[i] < heap[(i - 1) / 2]) {
            std::swap(heap[i], heap[(i - 1) / 2]);
            i = (i - 1) / 2;
        }
    }

    int extractMin() {
        if (heap.empty()) {
            std::cerr << "Heap is empty!\n";
            return -1;
        }

        int min = heap[0];
        heap[0] = heap.back();
        heap.pop_back();
        heapify(0);
        return min;
    }

private:
    void heapify(int i) {
        int left = 2 * i + 1, right = 2 * i + 2, smallest = i;

        if (left < heap.size() && heap[left] < heap[smallest])
            smallest = left;
        if (right < heap.size() && heap[right] < heap[smallest])
            smallest = right;

        if (smallest != i) {
            std::swap(heap[i], heap[smallest]);
            heapify(smallest);
        }
    }
};

int main() {
    MinHeap heap;

    heap.insert(10);
    heap.insert(5);
    heap.insert(20);
    heap.insert(15);

    std::cout << "Min element: " << heap.extractMin() << "\n";
    std::cout << "Min element: " << heap.extractMin() << "\n";

    return 0;
}
