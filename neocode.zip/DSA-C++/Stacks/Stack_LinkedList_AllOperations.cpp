#include <iostream>

using namespace std;

class Node {
    public:
        int data;
        Node* next;

        Node(int value) {
            data = value;
            next = nullptr;
        }
};

class Stack {
    private:
        Node* top;

    public:
        Stack() {
            top = nullptr;
        }

        bool isEmpty() {
            return top == nullptr;
        }

        void push(int item) {
            Node* newNode = new Node(item);
            newNode->next = top;
            top = newNode;
            cout << "Pushed item: " << item << endl;
        }

        int pop() {
            if (isEmpty()) {
                cout << "Stack Underflow! Cannot pop item." << endl;
                return -1;
            } else {
                Node* temp = top;
                int poppedItem = temp->data;
                top = top->next;
                delete temp;
                cout << "Popped item: " << poppedItem << endl;
                return poppedItem;
            }
        }

        int peek() {
            if (isEmpty()) {
                cout << "Stack is empty!" << endl;
                return -1;
            } else {
                return top->data;
            }
        }

        int count() {
            int count = 0;
            Node* temp = top;
            while (temp != nullptr) {
                count++;
                temp = temp->next;
            }
            return count;
        }

        void display() {
            if (isEmpty()) {
                cout << "Stack is empty." << endl;
            } else {
                Node* temp = top;
                cout << "All values in the stack are: ";
                while (temp != nullptr) {
                    cout << temp->data << " -> ";
                    temp = temp->next;
                }
                cout << "NULL" << endl;
            }
        }
};

int main() {
    Stack st;
    int option, value;

    do {
        cout << "___________________Select an operation_____________________" << endl;
        cout << "1. Push a value onto the stack" << endl;
        cout << "2. Pop a value from the stack" << endl;
        cout << "3. Check if the stack is empty" << endl;
        cout << "4. Peek at the top value of the stack" << endl;
        cout << "5. Get the count of items in the stack" << endl;
        cout << "6. Display all stack values" << endl;
        cout << "7. Clear the screen" << endl;
        cout << "0. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> option;

        switch (option) {
            case 1:
                cout << "Enter value to push: ";
                cin >> value;
                st.push(value);
                break;
            case 2:
                st.pop();
                break;
            case 3:
                if (st.isEmpty())
                    cout << "Stack is empty" << endl;
                else
                    cout << "Stack is not empty" << endl;
                break;
            case 4:
                if (!st.isEmpty()) {
                    cout << "Top value: " << st.peek() << endl;
                }
                break;
            case 5:
                cout << "Number of items in the stack: " << st.count() << endl;
                break;
            case 6:
                st.display();
                break;
            case 7:
                system("clear");
                break;
            case 0:
                cout << "Exiting... Thank you!" << endl;
                break;
            default:
                cout << "Invalid option! Please try again." << endl;
        }

    } while (option != 0);

    return 0;
}
