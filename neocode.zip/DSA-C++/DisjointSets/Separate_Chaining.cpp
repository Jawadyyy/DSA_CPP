#include <iostream>
using namespace std;

const int TABLE_SIZE = 10;

class ListNode {
public:
    int value;
    ListNode* next;
    ListNode(int val) {
        value = val;
        next =NULL;
    }
};

class HashTable {
private:
    ListNode* table[TABLE_SIZE];

    int hash(int key) {
        return key % TABLE_SIZE;
    }

public:
    HashTable() {
        for (int i = 0; i < TABLE_SIZE; ++i) {
            table[i] = NULL;
        }
    }

    void insert(int key) {
    int index = hash(key);
    ListNode* newNode = new ListNode(key);
    newNode->next = table[index];
    table[index] = newNode;
}


    void displayTable() {
        for (int i = 0; i < TABLE_SIZE; ++i) {
            cout << "Index " << i << ": ";
            ListNode* current = table[i];
            while (current) {
                cout << current->value << " ";
                current = current->next;
            }
            cout << endl;
        }
    }
};

int main() {
    HashTable hashTable;
    int n;

    cout << "Enter the number of values: ";
    cin >> n;

    for (int i = 0; i < n; ++i) {
        int value;
        cout << "Enter value " << i + 1 << ": ";
        cin >> value;
        hashTable.insert(value);
    }

    hashTable.displayTable();
    return 0;
}
