#include <iostream>
using namespace std;

const int tsize = 20;

class LinearHashTable {
private:
    int table[tsize];
    bool occupied[tsize];

    int hashFunction(int key) {
        return key % tsize;
    }

public:
    LinearHashTable() {
        for (int i = 0; i < tsize; i++) {
            table[i] = -1;
            occupied[i] = false;
        }
    }

    void insertLinearProbing(int key) {
        int index = hashFunction(key);

        while (occupied[index]) {
            index = (index + 1) % tsize;
        }

        table[index] = key;
        occupied[index] = true;
    }

    void insertQuadraticProbing(int key) {
        int index = hashFunction(key);
        int i = 0;

        while (occupied[(index + i * i) % tsize]) {
            i++;
        }

        index = (index + i * i) % tsize;
        table[index] = key;
        occupied[index] = true;
    }

    void display() {
        for (int i = 0; i < tsize; i++) {
            if (occupied[i]) {
                cout << "Index " << i << ": Number Found: " << table[i] << endl;
            } else {
                cout << "Index " << i << ": is Empty" << endl;
            }
        }
    }

    void clear() {
        for (int i = 0; i < tsize; i++) {
            table[i] = -1;
            occupied[i] = false;
        }
    }
};

int main() {
    LinearHashTable table;
    int n, value;

    cout << "Enter the number of values you want to insert: ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        cout << "Enter value " << i + 1 << ": ";
        cin >> value;

        table.insertLinearProbing(value);
    }

    cout << "HashTable: " << endl;
    table.display();

    return 0;
}