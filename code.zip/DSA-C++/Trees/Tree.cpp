#include <iostream>
#include <queue>

using namespace std;

class TreeNode
{
public:
    int data;
    TreeNode *left;
    TreeNode *right;

    TreeNode(int data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
};

bool BFS(TreeNode *root, int target)
{
    if (!root)
        return false;

    queue<TreeNode *> q;
    q.push(root);

    while (!q.empty())
    {
        TreeNode *current = q.front();
        q.pop();

        if (current->data == target)
            return true;

        if (current->left)
            q.push(current->left);

        if (current->right)
            q.push(current->right);
    }

    return false;
}

bool DFS(TreeNode *root, int target, const string &type)
{
    if (!root)
        return false;

    if (type == "preorder")
        return preOrderSearch(root, target);
    else if (type == "inorder")
        return inOrderSearch(root, target);
    else if (type == "postorder")
        return postOrderSearch(root, target);

    return false;
}

bool preOrderSearch(TreeNode *node, int target)
{
    if (!node)
        return false;
    if (node->data == target)
        return true;
    return preOrderSearch(node->left, target) || preOrderSearch(node->right, target);
}

bool inOrderSearch(TreeNode *node, int target)
{
    if (!node)
        return false;
    if (inOrderSearch(node->left, target))
        return true;
    if (node->data == target)
        return true;
    return inOrderSearch(node->right, target);
}

bool postOrderSearch(TreeNode *node, int target)
{
    if (!node)
        return false;
    if (postOrderSearch(node->left, target))
        return true;
    if (postOrderSearch(node->right, target))
        return true;
    return node->data == target;
}

int main()
{
    TreeNode *root = new TreeNode(1);
    TreeNode *node2 = new TreeNode(2);
    TreeNode *node3 = new TreeNode(3);
    TreeNode *node4 = new TreeNode(4);

    root->left = node2;
    root->right = node3;
    node2->left = node4;

    int target = 3;

    cout << "Searching for " << target << " using BFS: " << (BFS(root, target) ? "Found" : "Not Found") << endl;

    cout << "Searching for " << target << " using Preorder DFS: " << (DFS(root, target, "preorder") ? "Found" : "Not Found") << endl;

    return 0;
}
