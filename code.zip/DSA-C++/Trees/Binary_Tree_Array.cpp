#include <iostream>
using namespace std;

class BinaryTreeArray {
private:
    int* tree;        // Pointer to the dynamically allocated array
    int capacity;     // Current capacity of the array
    int size;         // Current number of elements in the tree

    // Method to resize the array when it's full
    void resize() {
        int newCapacity = capacity * 2;   // Double the capacity
        int* newTree = new int[newCapacity];
        
        // Copy the old elements into the new array
        for (int i = 0; i < capacity; i++) {
            newTree[i] = tree[i];
        }
        
        // Initialize new slots as empty (-1)
        for (int i = capacity; i < newCapacity; i++) {
            newTree[i] = -1;
        }
        
        // Delete the old array and assign the new one
        delete[] tree;
        tree = newTree;
        capacity = newCapacity;
    }

public:
    // Constructor to initialize the tree with an initial capacity
    BinaryTreeArray(int initialCapacity = 10) {
        capacity = initialCapacity;
        size = 0;
        tree = new int[capacity];
        
        // Initialize all positions with -1 to denote empty nodes
        for (int i = 0; i < capacity; i++) {
            tree[i] = -1;
        }
    }

    // Destructor to free allocated memory
    ~BinaryTreeArray() {
        delete[] tree;
    }

    // Insert a value at a specific index
    void insert(int value) {
        // Resize if the array is full
        if (size == capacity) {
            resize();
        }
        
        // Insert the value at the next available position
        tree[size] = value;
        size++;
    }

    // Display the binary tree array
    void display() const {
        for (int i = 0; i < capacity; i++) {
            if (tree[i] != -1)
                cout << "Node at index " << i << ": " << tree[i] << endl;
            else
                cout << "Node at index " << i << ": NULL" << endl;
        }
    }

    // Get the left child index
    int leftChild(int index) const {
        int left = 2 * index + 1;
        if (left >= capacity || tree[left] == -1) return -1;
        return left;
    }

    // Get the right child index
    int rightChild(int index) const {
        int right = 2 * index + 2;
        if (right >= capacity || tree[right] == -1) return -1;
        return right;
    }

    // Get the parent index
    int parent(int index) const {
        if (index == 0) return -1;
        return (index - 1) / 2;
    }
};

int main() {
    BinaryTreeArray bt(3);  // Start with an initial capacity of 3

    bt.insert(4);           // Insert root
    bt.insert(6);           // Insert left child of root
    bt.insert(7);           // Insert right child of root
    bt.insert(9);           // Insert additional node, causing a resize

    bt.display();

    return 0;
}
