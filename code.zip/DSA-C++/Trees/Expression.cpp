#include <iostream>
using namespace std;

// Node structure for binary expression tree
class ExprNode {
public:
    char value;
    ExprNode* left;
    ExprNode* right;

    ExprNode(char val) {
        value = val;
        left = NULL;
        right = NULL;
    }
};

// Inorder traversal for Infix expression
void infix(ExprNode* node) {
    if (node == NULL) return;

    if (node->left || node->right) cout << "(";
    infix(node->left);
    cout << node->value;
    infix(node->right);
    if (node->left || node->right) cout << ")";
}

// Preorder traversal for Prefix expression
void prefix(ExprNode* node) {
    if (node == NULL) return;

    cout << node->value << " ";
    prefix(node->left);
    prefix(node->right);
}

// Postorder traversal for Postfix expression
void postfix(ExprNode* node) {
    if (node == NULL) return;

    postfix(node->left);
    postfix(node->right);
    cout << node->value << " ";
}

int main() {
    // Construct the tree for ((4 + 2) * 3)
    ExprNode* root = new ExprNode('*');
    root->left = new ExprNode('+');
    root->left->left = new ExprNode('4');
    root->left->right = new ExprNode('2');
    root->right = new ExprNode('3');

    cout << "Infix expression: ";
    infix(root);
    cout << endl;

    cout << "Prefix expression: ";
    prefix(root);
    cout << endl;

    cout << "Postfix expression: ";
    postfix(root);
    cout << endl;

    return 0;
}
