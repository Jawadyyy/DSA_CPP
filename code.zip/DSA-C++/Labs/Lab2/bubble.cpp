#include <iostream>

using namespace std;

void bubblesort(int array[], int s)
{
    int swap;
    for (int j = 0; j < s - 1; j++)
    {
        for (int z = 0; z < s - j - 1; z++)
        {
            if (array[z] > array[z + 1])
            {
                swap = array[z];
                array[z] = array[z + 1];
                array[z + 1] = swap;
            }
        }
    }

    cout << "Sorted array: ";
    for (int k = 0; k < s; k++)
    {
        cout << array[k] << " ";
    }
    cout << endl;
}

int main()
{
    int size = 10;
    int ray[size] = {2,4,1,19,24,11,42,13,65,87};  

    bubblesort(ray, size);
    return 0;
}