#include <iostream>
using namespace std;

void ptr() {
    int ivar = 20;
    float fvar = 23.4;
    char avar = 'b';

    int *ptr1 = &ivar;
    float *ptr2 = &fvar;
    char *ptr3 = &avar;

    cout << "Address of ivar (int): " << ptr1 << endl;
    cout << "Value of ivar: " << ivar << endl;
    cout << "Value at *ptr1: " << *ptr1 << endl;

    cout << "Address of fvar (float): " << ptr2 << endl;
    cout << "Value of fvar: " << fvar << endl;
    cout << "Value at *ptr2: " << *ptr2 << endl;

    cout << "Address of avar (char): " << static_cast<void*>(ptr3) << endl;
    cout << "Value of avar: " << avar << endl;
    cout << "Value at *ptr3: " << *ptr3 << endl;

    ptr1++;
    ptr2++;
    ptr3++;

    cout << "---------------------------------------" << endl;
    cout << "After incrementing pointers:" << endl;

    cout << "New address of ptr1 (ivar): " << ptr1 << endl;
    cout << "Value at *ptr1 (undefined): " << *ptr1 << endl;

    cout << "New address of ptr2 (fvar): " << ptr2 << endl;
    cout << "Value at *ptr2 (undefined): " << *ptr2 << endl;

    cout << "New address of ptr3 (avar): " << static_cast<void*>(ptr3) << endl;
    cout << "Value at *ptr3 (undefined): " << *ptr3 << endl;
}

int main() {
    ptr();
    return 0;
}
