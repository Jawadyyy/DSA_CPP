#include <iostream>
#include <string>
using namespace std;

class ShoppingItem
{
private:
    string name;
    int quantity;
    double price;
    ShoppingItem *next;
    ShoppingItem *prev;

public:
    ShoppingItem(string itemName, int itemQuantity, double itemPrice)
    {
        this->name = itemName;
        this->quantity = itemQuantity;
        this->price = itemPrice;
        next = NULL;
        prev = NULL;
    }

    void appendItem(ShoppingItem **head, string itemName, int itemQuantity, double itemPrice)
    {
        ShoppingItem *newItem = new ShoppingItem(itemName, itemQuantity, itemPrice);
        newItem->next = *head;
        newItem->prev = NULL;

        if (*head != NULL)
        {
            (*head)->prev = newItem;
        }

        *head = newItem;
    }

    void printListForward(ShoppingItem *n)
    {
        while (n != NULL)
        {
            cout << "(Item): " << n->name << " (Quantity): " << n->quantity << " (Price): " << n->price << endl;
            n = n->next;
        }
    }

    void printListBackward(ShoppingItem *n)
    {
        while (n != NULL)
        {
            cout << "(Item): " << n->name << " (Quantity): " << n->quantity << " (Price): " << n->price << endl;
            n = n->prev;
        }
    }

    double calculateTotalCost(ShoppingItem *n)
    {
        double total = 0.0;
        while (n != NULL)
        {
            total += n->price * n->quantity; 
            n = n->next;
        }
        return total;
    }

    ShoppingItem *getLastItem(ShoppingItem *n)
    {
        while (n->next != NULL)
        {
            n = n->next;
        }
        return n;
    }
};

int main()
{
    ShoppingItem *head = NULL;
    ShoppingItem item("", 0, 0.0);

    item.appendItem(&head, "Apples", 5, 1.5);
    item.appendItem(&head, "Bananas", 3, 2.0);
    item.appendItem(&head, "Cherries", 2, 3.0);
    item.appendItem(&head, "Oranges", 1, 2.5);

    cout << "Shopping List (Printing Forward):" << endl;
    item.printListForward(head);

    ShoppingItem *last = item.getLastItem(head);
    cout << "Shopping List (Prinitng Backward):" << endl;
    item.printListBackward(last);

    double totalCost = item.calculateTotalCost(head);
    cout << "Total Cost: $" << totalCost << endl;

    return 0;
}
