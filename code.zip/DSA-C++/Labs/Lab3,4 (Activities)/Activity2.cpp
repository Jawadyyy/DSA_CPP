#include <iostream>

using namespace std;

class Node
{
private:
    int data;
    Node *next;

public:
    Node(int data) {
        this->data = data;
        next = NULL;
    }

    void insertStart(Node **h, int val) {
        Node *newNode = new Node(val);
        newNode->next = *h;
        *h = newNode;
    }

    void printList(Node *head) {
        Node *temp = head;
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
        delete temp;
    }
};

int main()
{
    Node *head = NULL;
    Node *obj;

    obj->insertStart(&head,1);
    obj->insertStart(&head,3);
    obj->insertStart(&head,5);
    obj->insertStart(&head,7);
    obj->insertStart(&head,9);
    obj->insertStart(&head,11);
    obj->insertStart(&head,13);
    cout << "Before Inserting at Start: " << endl;
    obj->printList(head);
    obj->insertStart(&head,0);
    cout << "After Inserting at Start: " << endl;
    obj->printList(head);

    return 0;
}