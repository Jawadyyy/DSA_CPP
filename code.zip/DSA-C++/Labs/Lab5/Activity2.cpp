#include <iostream>

using namespace std;

class Node {
    public:
        int data;
        Node* next;
        
        Node(int data) {
            this->data = data;
            next = NULL;
        }
};

class Stack {
    private:
        Node* top;
    
    public:
        Stack() {
            top = NULL;
        }

        bool isFull() {
            if(top->next == NULL) {
                return true;
            } else {
                return false;
            }
        }

        void push(int val) {
            Node* newNode = new Node(val);
            newNode->next = top;
            top = newNode;
            cout << "Pushed Item: " << val << endl;
        }

        int pop() {
            if (top == NULL) {
                cout << "Stack Underflow" << endl;
                return -1;
            }
            Node* temp = top;
            int poppedItem = temp->data;
            top = top->next;
            delete temp;
            cout << "Popped Item: " << poppedItem << endl;
            return poppedItem;
        }
};

int main() {
    Stack st;

    cout << "Pushing Elements: " << endl;
    st.push(10);
    st.push(20);
    st.push(30);

    cout << "Popping Elements: " << endl;
    st.pop();
    st.pop();
    st.pop();

    return 0;
}
