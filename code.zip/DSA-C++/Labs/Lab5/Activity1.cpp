#include <iostream>
#include <string>

using namespace std;

const int size = 10;

class Stack {
    private:
        int top;
        int ray[size];

    public:
        Stack() {
            top = -1;
            for(int i = 0; i<size; i++) {
                ray[i] = 0;
            }
        }

        bool isEmpty() {
            if(top == -1) {
                return true;
            } else {
                return false;
            }
        }

        bool isFull() {
            if(top == size-1) {
                return true;
            } else {
                return false; 
            }
        }

        int stackSize() {
            return (top+1);
        }

        void push(int val) {
            if(isFull()) {
                cout << "Stack Overflow" << endl;
            } else {
                top++;
                ray[top] = val;
            }
        }

        int pop() {
            if(isEmpty()) {
                cout << "Stack Underflow" << endl;
                return 0;
            } else {
                int popValue = ray[top];
                ray[top] = 0;
                top--;
                return popValue;
            }
        }

};

int main() {

    Stack stack;

    cout << "Pushing values onto the stack:" << endl;
    stack.push(10);
    stack.push(20);
    stack.push(30);

    cout << "Size of the Stack is: " << stack.stackSize() << endl;

    cout << "Popping values onto the stack:" << endl;

    cout << stack.pop() << endl;
    cout << stack.pop() << endl;
    cout << stack.pop() << endl;

    return 0;
}