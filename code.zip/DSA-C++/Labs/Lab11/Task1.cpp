#include <iostream>
using namespace std;

class DisjointSet {
public:
    DisjointSet(int n) {
        parent = new int[n];
        rank = new int[n];
        for (int i = 0; i < n; ++i) {
            parent[i] = i;
            rank[i] = 0;
        }
    }

    ~DisjointSet() {
        delete[] parent;
        delete[] rank;
    }

    int find(int x) {
        if (parent[x] != x) {
            parent[x] = find(parent[x]);
        }
        return parent[x];
    }

    void unionSets(int x, int y) {
        int rootX = find(x);
        int rootY = find(y);
        if (rootX != rootY) {
            // Union by rank
            if (rank[rootX] < rank[rootY]) {
                parent[rootX] = rootY;
            } else if (rank[rootX] > rank[rootY]) {
                parent[rootY] = rootX;
            } else {
                parent[rootX] = rootY;
                rank[rootY]++;
            }
        }
    }

private:
    int* parent;
    int* rank;
};

int countConnectedComponents(int n, int edges[][2], int numEdges) {
    DisjointSet ds(n);
    for (int i = 0; i < numEdges; ++i) {
        int u = edges[i][0];
        int v = edges[i][1];
        ds.unionSets(u, v);
    }

    int componentCount = 0;
    for (int i = 0; i < n; ++i) {
        if (ds.find(i) == i) {
            componentCount++;
        }
    }
    return componentCount;
}

int main() {
    int n = 6;
    int edges[][2] = {{0, 1}, {1, 2}, {3, 4}};
    int numEdges = 3;

    int components = countConnectedComponents(n, edges, numEdges);
    cout << "Number of connected components: " << components << endl;

    return 0;
}
