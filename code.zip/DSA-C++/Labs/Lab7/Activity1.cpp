#include <iostream>
#include <queue>
using namespace std;

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int value) {
        data = value;
        left = NULL;
        right = NULL;
    }
};

class BinaryTree {
public:
    Node* root;

    BinaryTree() {
        root = NULL;
    }

    Node* insert(Node* node, int value) {
        if (node == NULL) {
            return new Node(value);  
        }

        if (value < node->data) {
            node->left = insert(node->left, value);
        } else {
            node->right = insert(node->right, value);
        }
        return node;
    }

    void inorder(Node* node) {
        if (node == NULL) return;

        inorder(node->left);
        cout << node->data << " ";
        inorder(node->right);
    }

    bool BFS(Node *root, int target) {
        if (!root)
            return false;

        queue<Node *> q;
        q.push(root);

        while (!q.empty()) {
            Node *current = q.front();
            q.pop();

            if (current->data == target)
                return true;

            if (current->left)
                q.push(current->left);

            if (current->right)
                q.push(current->right);
        }

    return false;
}
};

int main() {
    BinaryTree bt;
    bt.root = bt.insert(bt.root, 10);  
    bt.insert(bt.root, 5);   
    bt.insert(bt.root, 15);     
    bt.insert(bt.root, 7);   
    bt.insert(bt.root, 12);
    bt.insert(bt.root, 3);

    cout << "Inorder traversal: ";
    bt.inorder(bt.root);
    cout << endl;

    if(bt.BFS(bt.root,7))
        cout << "Value 7 Found" << endl; 
    else
        cout << "Value 7 Not Found" << endl;

    if(bt.BFS(bt.root,11))
        cout << "Value 11 Found" << endl; 
    else
        cout << "Value 11 Not Found" << endl;

    return 0;
}