#include <iostream>
using namespace std;

class Array
{
public:
    void display(int array[][2])
    {
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 2; j++)
            {
                cout << "\t" << array[i][j];
            }
            cout << endl;
        }
    }
};
int main()
{
    Array obj;

    int arr[4][2] = {
        {10, 11},
        {20, 21},
        {30, 31},
        {40, 41}};
    cout << "Printing a 2D Array: " << endl;
    obj.display(arr);

    return 0;
}