#include <iostream>

using namespace std;

void display(int numbers[])
{
    for (int i = 0; i < 10; i++)
    {
        cout << numbers[i] << " ";
    }
}

void reverse(int numbers[])
{
    int rev[10];
    for(int i = 0, j = 9; i < 10 && j >= 0; i++, j--) {
    rev[j] = numbers[i];
    }

    display(rev);
}

int max(int numbers[])
{
    int mx = 0;
    for (int i = 0; i < 10; i++)
    {
        if (numbers[i + 1] < numbers[i])
        {
            mx = numbers[i];
        }
    }

    return mx;
}

int min(int numbers[])
{
    int mn = 0;
    for (int i = 0; i < 10; i++)
    {
        if (numbers[i + 1] > numbers[i])
        {
            mn = numbers[i];
        }
    }

    return mn;
}

double average(int numbers[])
{
    double avg = 0;
    double sum = 0;
    for (int i = 0; i < 10; i++)
    {
        sum += numbers[i];
    }
    avg = sum / 10;

    return avg;
}

int main()
{

    int num[10] = {7, 5, 6, 12, 35, 42, 18, 23, 50, 4};

    cout << "Original Array is: " << endl;

    display(num);

    cout << endl;

    cout << "Reversed array is: " << endl;

    reverse(num);

    cout << endl;

    cout << "Maximum is: " << max(num) << endl;

    cout << "Minimum is: " << min(num) << endl;

    cout << "Average is: " << average(num) << endl;

    return 0;
}