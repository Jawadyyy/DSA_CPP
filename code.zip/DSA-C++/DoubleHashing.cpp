#include <iostream>
using namespace std;

const int tsize = 20;

class DoubleHashing {
private:
    int table[tsize];
    bool occupied[tsize];

    int hashFunction1(int key) {
        return key % tsize;
    }

    int hashFunction2(int key) {
        return 1 + (key % (tsize - 1));
    }

public:
    DoubleHashing() {
        for (int i = 0; i < tsize; i++) {
            table[i] = -1;
            occupied[i] = false;
        }
    }

    void insertDoubleHashing(int key) {
        int index1 = hashFunction1(key);
        int index2 = hashFunction2(key);
        int i = 0;

        while (occupied[(index1 + i * index2) % tsize]) {
            i++;
        }

        int index = (index1 + i * index2) % tsize;
        table[index] = key;
        occupied[index] = true;
    }

    void display() {
        for (int i = 0; i < tsize; i++) {
            if (occupied[i]) {
                cout << "Index " << i << ": Number Found: " << table[i] << endl;
            } else {
                cout << "Index " << i << ": is Empty" << endl;
            }
        }
    }

};

int main() {
    DoubleHashing table;
    int n, value;

    cout << "Enter the number of values you want to insert: ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        cout << "Enter value " << i + 1 << ": ";
        cin >> value;

        table.insertDoubleHashing(value);
    }

    cout << "HashTable: " << endl;
    table.display();

    return 0;
}
